// File: constants.h
// Author: Paige Meyer
// Assignment: 5
// Date: 2/27/2015

const int array_size = 10;				// have array size to be 10 initially
const int sentinel = 0;					// value to end entering numbers
