#include "squareType.h"

squareType::squareType(double side) : rectangleType(side,side)
{
}

squareType::squareType()
{
}

void squareType::setDimension(double side)
{
   rectangleType::setDimension(side,side);
}

double squareType::getSide() const
{
   return getLength();
}
