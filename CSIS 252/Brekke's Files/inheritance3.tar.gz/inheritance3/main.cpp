#include <iostream>
using namespace std;
#include "derived.h"

int main()
{
   Derived a(5,3);
   cout << "x=" << a.getX() << "   y=" << a.getY() << endl;
   return 0;
}
