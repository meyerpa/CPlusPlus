#ifndef _DERIVED_H_
#define _DERIVED_H_
#include "base.h"

class Derived : public Base
{
   public:
      Derived(int,int);
      void setY(int);
      int getY() const;
   private:
      int y;
};

#endif