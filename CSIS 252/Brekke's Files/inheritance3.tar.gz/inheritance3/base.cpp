#include "base.h"

Base::Base(int value)
{
   setX(value);
}

int Base::getX() const
{
   return x;
};

void Base::setX(int value)
{
   x = value;
}
