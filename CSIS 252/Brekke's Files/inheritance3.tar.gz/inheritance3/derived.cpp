#include "derived.h"

Derived::Derived(int value1, int value2) : Base(value1)
{
   setY(value2);
}

void Derived::setY(int value)
{
   y = value;
}

int Derived::getY() const
{
   return y;
}
   