#ifndef _BASE_H_
#define _BASE_H_

class Base
{
   public:
      Base(int);
      int getX() const;
      void setX(int);
   private:
      int x;
};

#endif
