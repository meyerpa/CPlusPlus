#include <iostream>
#include <fstream>
using namespace std;
#include "constants.h"
#include "info.h"

void readInfo(personInfo people[], int& count);
void sortInfo(personInfo people[], int g);
void outputInfo(personInfo people[], int count);

int main ()
{
  personInfo people[maxpeople];
  int count;
  readInfo(people, count);
  sortInfo(people, count);
  outputInfo(people, count);
  return 0;
}
