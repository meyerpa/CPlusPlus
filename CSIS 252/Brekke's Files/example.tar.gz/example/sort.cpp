#include <iostream>
#include <fstream>
using namespace std;
#include "constants.h"
#include "info.h"

void readInfo(personInfo people[], int& count);

void sortInfo(personInfo people[], int g)
{
  personInfo tmpInfo;
  for (int i = 0; i < g - 1; i++)
  {
    int oldest = i;
    for (int r = i + 1; r < g; r++)
    {
      if (people[r].age > people[oldest].age)
      {
	oldest = r;
      }
    }
    tmpInfo = people[i];
    people[i] = people[oldest];
    people[oldest] = tmpInfo;
  }
}
