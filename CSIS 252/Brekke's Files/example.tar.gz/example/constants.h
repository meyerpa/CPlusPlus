const int maxpeople = 20;
