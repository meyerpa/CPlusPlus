#include <iostream>
using namespace std;
#include <string>

struct personInfo
{
  string name;
  int age;
};



