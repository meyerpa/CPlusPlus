#include <iostream>
using namespace std;
#include <string>
#include <fstream>
#include "info.h"
#include "constants.h"

void readInfo(personInfo people[], int& count)
{
  ifstream infile;
  string name;
  infile.open("data");
  count = 0;
  infile.ignore(80, '\n');
  getline(infile, name);
  while (!infile.eof() && count < maxpeople)
  {
    people[count].name = name;
    infile >> people[count].age;
    infile.ignore(80, '\n');
    count++;
    getline(infile, name);
  }
  infile.close();
}

