#include <iostream>
#include <iomanip>
using namespace std;
#include <fstream>
#include "constants.h"
#include "info.h"

void readInfo(personInfo people[], int& count);
void sortInfo(personInfo people[], int g);

void outputInfo(personInfo people[], int count)
{
  cout << " Name                    Age\n";
  cout << "------                  -----\n";
  for (int i = 0; i < count; i++)
  {
    cout << setw(20) << left << people[i].name;
    cout << setw(9) << right << people[i].age << endl;
  }
  cout << endl;
}
