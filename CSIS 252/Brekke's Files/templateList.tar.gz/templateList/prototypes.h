#include "arrayListType.h"
int menu();
void addItem(arrayListType<GroceryItem>&);
void deleteItem(arrayListType<GroceryItem>&);
int totalItems(const arrayListType<GroceryItem>&);
void totalOfItem(const arrayListType<GroceryItem>&);
